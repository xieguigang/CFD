.NET assembly files [net6.0]

CFD.dll
CFD_clr.dll
Microsoft.VisualBasic.Data.BinaryData.dll
Microsoft.VisualBasic.Data.GraphTheory.dll
Microsoft.VisualBasic.Data.IO.MessagePack.dll
Microsoft.VisualBasic.DataStorage.HDSPack.dll
Microsoft.VisualBasic.Imaging.Physics.dll
Microsoft.VisualBasic.Math.Core.dll
