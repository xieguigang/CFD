// export R# source type define for javascript/typescript language
//
// package_source=CFD

declare namespace CFD {
   module _ {
      /**
      */
      function onLoad(): object;
   }
}

