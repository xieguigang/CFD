.NET CLR object documents at here!
